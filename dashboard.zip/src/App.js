import React from "react";
import DashboardLayout from "./pages/DashboardLayout";



const App = () => {
  return <DashboardLayout />;
};

export default App;
